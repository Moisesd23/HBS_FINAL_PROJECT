import tkinter as tk
from tkinter import messagebox, PhotoImage

def make_payment(parent):
    payment_window = tk.Toplevel(parent)
    payment_window.title("Make a Payment")

    tk.Label(payment_window, text="Recipient Name:").pack()
    recipient_entry = tk.Entry(payment_window)
    recipient_entry.pack()

    tk.Label(payment_window, text="Amount:").pack()
    amount_entry = tk.Entry(payment_window)
    amount_entry.pack()

    tk.Label(payment_window, text="Purpose:").pack()
    purpose_entry = tk.Entry(payment_window)
    purpose_entry.pack()

    try:
        card_img = PhotoImage(file="generic-profile-placeholder-icon-nqu0ajnbs6wkw14q.png")
        tk.Label(payment_window, image=card_img).pack()
        tk.Label(payment_window, text="User Payment Icon").pack()
        payment_window.card_img = card_img
    except:
        tk.Label(payment_window, text="[Card Icon Placeholder]").pack()

    def submit_payment():
        if not recipient_entry.get() or not amount_entry.get() or not purpose_entry.get():
            messagebox.showerror("Input Error", "All fields must be filled.")
            return
        try:
            float(amount_entry.get())
        except ValueError:
            messagebox.showerror("Input Error", "Amount must be a number.")
            return
        messagebox.showinfo("Success", "Payment submitted successfully!")
        payment_window.destroy()

    tk.Button(payment_window, text="Submit", command=submit_payment).pack(pady=5)
    tk.Button(payment_window, text="Cancel", command=payment_window.destroy).pack()