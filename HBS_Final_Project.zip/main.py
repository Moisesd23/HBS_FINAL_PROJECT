import tkinter as tk
from dashboard import open_dashboard
from tkinter import messagebox

def login():
    if not username_entry.get() or not password_entry.get():
        messagebox.showerror("Input Error", "Username and password cannot be empty.")
        return
    root.destroy()
    open_dashboard()

# Login Window
root = tk.Tk()
root.title("HBS - Login")

tk.Label(root, text="Username:").pack()
username_entry = tk.Entry(root)
username_entry.pack()

tk.Label(root, text="Password:").pack()
password_entry = tk.Entry(root, show="*")
password_entry.pack()

tk.Button(root, text="Login", command=login).pack(pady=5)
tk.Button(root, text="Exit", command=root.quit).pack(pady=5)

root.mainloop()