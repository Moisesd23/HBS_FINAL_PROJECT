import tkinter as tk
from payments import make_payment
from transfers import transfer, internal_transfer
from tkinter import PhotoImage

def open_dashboard():
    dashboard = tk.Tk()
    dashboard.title("HBS - Dashboard")

    try:
        logo = PhotoImage(file="HBS_LOGO.png")
        tk.Label(dashboard, image=logo).pack()
        tk.Label(dashboard, text="Discovering New Horizons").pack()
        dashboard.logo = logo
    except:
        tk.Label(dashboard, text="[Bank Logo Image Placeholder]").pack()

    tk.Label(dashboard, text="Welcome to HBS Dashboard", font=("Arial", 18)).pack(pady=10)

    tk.Button(dashboard, text="Make a Payment", command=lambda: make_payment(dashboard)).pack(pady=5)
    tk.Button(dashboard, text="Transfer to Another Account", command=lambda: transfer(dashboard)).pack(pady=5)
    tk.Button(dashboard, text="Internal Transfer", command=lambda: internal_transfer(dashboard)).pack(pady=5)
    tk.Button(dashboard, text="Exit", command=dashboard.quit).pack(pady=5)

    dashboard.mainloop()