import tkinter as tk
from tkinter import messagebox

def transfer(parent):
    transfer_window = tk.Toplevel(parent)
    transfer_window.title("Transfer to Another Account")

    tk.Label(transfer_window, text="Recipient Account Number:").pack()
    account_entry = tk.Entry(transfer_window)
    account_entry.pack()

    tk.Label(transfer_window, text="Transfer Amount:").pack()
    transfer_amount_entry = tk.Entry(transfer_window)
    transfer_amount_entry.pack()

    def submit_transfer():
        if not account_entry.get() or not transfer_amount_entry.get():
            messagebox.showerror("Input Error", "All fields must be filled.")
            return
        try:
            float(transfer_amount_entry.get())
        except ValueError:
            messagebox.showerror("Input Error", "Amount must be a number.")
            return
        messagebox.showinfo("Success", "Transfer completed successfully!")
        transfer_window.destroy()

    tk.Button(transfer_window, text="Submit", command=submit_transfer).pack(pady=5)
    tk.Button(transfer_window, text="Cancel", command=transfer_window.destroy).pack()

def internal_transfer(parent):
    internal_window = tk.Toplevel(parent)
    internal_window.title("Internal Transfer")

    tk.Label(internal_window, text="From Account:").pack()
    from_account = tk.Entry(internal_window)
    from_account.pack()

    tk.Label(internal_window, text="To Account:").pack()
    to_account = tk.Entry(internal_window)
    to_account.pack()

    tk.Label(internal_window, text="Amount:").pack()
    transfer_amount = tk.Entry(internal_window)
    transfer_amount.pack()

    def submit_internal():
        if not from_account.get() or not to_account.get() or not transfer_amount.get():
            messagebox.showerror("Input Error", "All fields must be filled.")
            return
        try:
            float(transfer_amount.get())
        except ValueError:
            messagebox.showerror("Input Error", "Amount must be a number.")
            return
        messagebox.showinfo("Success", "Internal transfer successful!")
        internal_window.destroy()

    tk.Button(internal_window, text="Submit", command=submit_internal).pack(pady=5)
    tk.Button(internal_window, text="Cancel", command=internal_window.destroy).pack()